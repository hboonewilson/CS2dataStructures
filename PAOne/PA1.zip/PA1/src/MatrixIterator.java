import java.util.Scanner;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.lang.Integer;

public class MatrixIterator<E extends Number> implements Iterator<MatrixEntry<E>> {
    private E[][] matrix; // matrix to iterate over
    private int row, col; // position in matrix
    MatrixIterator(E[][] matrix)
    {
        this.matrix = matrix;
        row = 0;
        col = 0;
    }


    /*
        return boolean
            if position in matrix exists for the row and column
     */
    public boolean hasNext()
    {
        // you code here
        return true;
        // change return False to your own code
    }

    /*
        return MatrixEntry<E>
            check if the next element exist
                true
                    return next element
                false
                    error
     */
    public MatrixEntry<E> next() {
        // your code here
        if (1 == 2)
            throw(new NoSuchElementException("MatrixIterator: no more elements in matrix"));
        // change code on lines 35-38 with your own code
    }

    /*
        main test case
     */
    public static void main(String[] args) {
        int[][] mat = { {3,4,5},
                        {7,0,-2},
                        {5,2,8}
                      };

        Integer[][] mat2 = new Integer[mat.length][mat[0].length];

        /*
            Using a nested for loop
                Convert int mat to an Interger[][]
                save into mat2
         */
            // your code here

        Iterator<MatrixEntry<Integer>> iter = new MatrixIterator<>(mat2);

        /*
            Cycle through iterator iter using a while loop:
                use methods:
                                hasNext
                                Next
         */

            // your code here

    }
}